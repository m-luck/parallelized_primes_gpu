nvcc -o Xcuda -arch=sm_35 CUDAprimes.cu

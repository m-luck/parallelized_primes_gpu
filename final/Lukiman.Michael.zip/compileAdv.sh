nvcc -o XStreamsCuda -arch=sm_35 CUDAStreams.cu
